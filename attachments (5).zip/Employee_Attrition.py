import pandas as pd
import numpy as np
df = pd.read_csv("HR-Employee-Attrition.csv")

print(df.head())

print(df.tail())

#Check rows and column
print(df.shape)

#Check column name
print(df.columns)

#Check datatype
print(df.dtypes)

#Check missing values
print(df.isnull().sum())

#Check Duplicate rows
print("Duplicate rows:",df.duplicated().sum())

#Check categorical values
categorical_columns = df.select_dtypes(include="str").columns

print(categorical_columns)

for column in categorical_columns:
    print("\n", column)
    print(df[column].unique())

#Check numercial data 
print(df.describe())

#Check numercial validation
print(df["Age"].min())
print(df["Age"].max())

#Check negative values
print((df.select_dtypes(include="number") < 0).sum())

#Check Employee Number 
print("Unique Employee Numbers:", df["EmployeeNumber"].nunique())
print("Total Employees:", len(df))

#Check uncessary column
print("EmployeeCount:", df["EmployeeCount"].unique())
print("StandardHours:", df["StandardHours"].unique())
print("Over18:", df["Over18"].unique())

# Remove columns that don't provide useful information

df = df.drop(columns=["EmployeeCount", "Over18", "StandardHours"])

print("Final shape:", df.shape)

# Save cleaned dataset

df.to_csv("HR_Employee_Attrition_Cleaned.csv", index=False)

print("Cleaned file saved successfully!")